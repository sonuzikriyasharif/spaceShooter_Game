const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const scoreDisplay = document.getElementById("score");
const statusDisplay = document.getElementById("status");

const WIDTH = canvas.width;
const HEIGHT = canvas.height;

let player;
let bullets;
let enemies;
let stars;
let score;
let frame;
let gameOver;
let keys = {};

function resetGame() {
    player = {
        x: WIDTH / 2,
        y: HEIGHT - 65,
        width: 34,
        height: 38,
        speed: 5
    };

    bullets = [];
    enemies = [];
    stars = Array.from({ length: 70 }, () => ({
        x: Math.random() * WIDTH,
        y: Math.random() * HEIGHT,
        size: Math.random() * 2 + 1
    }));

    score = 0;
    frame = 0;
    gameOver = false;
    keys = {};

    scoreDisplay.textContent = score;
    statusDisplay.textContent = "Destroy the enemies!";
}

function drawStars() {
    ctx.fillStyle = "white";

    stars.forEach(star => {
        ctx.fillRect(star.x, star.y, star.size, star.size);

        star.y += 1;

        if (star.y > HEIGHT) {
            star.y = 0;
            star.x = Math.random() * WIDTH;
        }
    });
}

function drawPlayer() {
    ctx.font = "36px Arial";
    ctx.textAlign = "center";
    ctx.fillText("🚀", player.x, player.y + 10);
}

function drawBullets() {
    ctx.fillStyle = "#00ffff";

    bullets.forEach(bullet => {
        ctx.fillRect(bullet.x - 3, bullet.y, 6, 15);
    });
}

function drawEnemies() {
    ctx.font = "30px Arial";
    ctx.textAlign = "center";

    enemies.forEach(enemy => {
        ctx.fillText("👾", enemy.x, enemy.y + 10);
    });
}

function shoot() {
    bullets.push({
        x: player.x,
        y: player.y - 20
    });
}

function updateGame() {
    if (gameOver) return;

    frame++;

    // Move the player
    if (keys.ArrowLeft || keys.a || keys.A) {
        player.x -= player.speed;
    }

    if (keys.ArrowRight || keys.d || keys.D) {
        player.x += player.speed;
    }

    player.x = Math.max(
        20,
        Math.min(WIDTH - 20, player.x)
    );

    // Shoot automatically while the fire button is held
    if (keys.Space && frame % 12 === 0) {
        shoot();
    }

    // Move bullets
    bullets.forEach(bullet => {
        bullet.y -= 7;
    });

    bullets = bullets.filter(bullet => bullet.y > 0);

    // Create enemies
    if (frame % 45 === 0) {
        enemies.push({
            x: Math.random() * (WIDTH - 40) + 20,
            y: -20,
            speed: 1.5 + Math.random() * 1.5
        });
    }

    // Move enemies
    enemies.forEach(enemy => {
        enemy.y += enemy.speed;
    });

    // Detect bullet-enemy collisions
    bullets = bullets.filter(bullet => {
        let hit = false;

        enemies = enemies.filter(enemy => {
            const distance = Math.hypot(
                bullet.x - enemy.x,
                bullet.y - enemy.y
            );

            if (distance < 25) {
                hit = true;
                score += 10;
                scoreDisplay.textContent = score;
                return false;
            }

            return true;
        });

        return !hit;
    });

    // Check whether an enemy reaches the player
    for (const enemy of enemies) {
        const distance = Math.hypot(
            player.x - enemy.x,
            player.y - enemy.y
        );

        if (distance < 30) {
            endGame();
            return;
        }
    }

    // An enemy reaching the bottom also ends the game
    if (enemies.some(enemy => enemy.y > HEIGHT)) {
        endGame();
        return;
    }

    draw();
    requestAnimationFrame(updateGame);
}

function draw() {
    ctx.clearRect(0, 0, WIDTH, HEIGHT);

    drawStars();
    drawBullets();
    drawEnemies();
    drawPlayer();
}

function endGame() {
    gameOver = true;
    statusDisplay.textContent = "Game Over!";

    ctx.fillStyle = "rgba(0, 0, 0, 0.8)";
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    ctx.fillStyle = "#ff4444";
    ctx.font = "bold 38px Arial";
    ctx.textAlign = "center";
    ctx.fillText("GAME OVER", WIDTH / 2, HEIGHT / 2 - 15);

    ctx.fillStyle = "white";
    ctx.font = "22px Arial";
    ctx.fillText(
        "Final Score: " + score,
        WIDTH / 2,
        HEIGHT / 2 + 25
    );

    ctx.font = "16px Arial";
    ctx.fillText(
        "Press Restart to play again",
        WIDTH / 2,
        HEIGHT / 2 + 65
    );
}

// Keyboard controls
document.addEventListener("keydown", event => {
    if (
        ["ArrowLeft", "ArrowRight", "Space"].includes(event.code)
    ) {
        event.preventDefault();
    }

    keys[event.code === "Space" ? "Space" : event.key] = true;
});

document.addEventListener("keyup", event => {
    keys[event.code === "Space" ? "Space" : event.key] = false;
});

// Touch and mouse buttons
function setupButton(id, key) {
    const button = document.getElementById(id);

    button.addEventListener("pointerdown", event => {
        event.preventDefault();
        keys[key] = true;
        button.setPointerCapture(event.pointerId);
    });

    function release() {
        keys[key] = false;
    }

    button.addEventListener("pointerup", release);
    button.addEventListener("pointercancel", release);
    button.addEventListener("lostpointercapture", release);
}

setupButton("left", "ArrowLeft");
setupButton("right", "ArrowRight");
setupButton("shoot", "Space");

// Restart
document.getElementById("restart").addEventListener("click", () => {
    resetGame();
    draw();
    requestAnimationFrame(updateGame);
});

// Start the game
resetGame();
draw();
requestAnimationFrame(updateGame);